'use strict';
/*
 * Serve a app (HTML) a partir da pasta public/.
 * Rotas /api/... sao tratadas pelos endpoints da API.
 * IMPORTANTE: no Flex Consumption as rotas sao avaliadas pela ordem alfabetica do nome das funcoes;
 * esta funcao apanha qualquer endereco, por isso o nome tem de ficar SEMPRE em ultimo (zzz...).
 */
const { app } = require('@azure/functions');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const ROOT = path.join(__dirname, '..', '..', 'public');
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2'
};
const cache = new Map();

function load(file) {
  if (cache.has(file)) return cache.get(file);
  const raw = fs.readFileSync(file);
  const entry = { raw, gz: zlib.gzipSync(raw, { level: 9 }) };
  cache.set(file, entry);
  return entry;
}

app.http('zzzStaticSite', {
  methods: ['GET', 'HEAD'], authLevel: 'anonymous', route: '{*path}',
  handler: async (request) => {
    let rel = String(request.params.path || '').replace(/^\/+/, '');
    if (rel.toLowerCase().startsWith('api/') || rel.toLowerCase() === 'api') {
      return { status: 404, jsonBody: { error: 'NAO_ENCONTRADO', message: 'Endpoint inexistente.' } };
    }
    if (!rel || rel.endsWith('/')) rel += 'index.html';
    const file = path.normalize(path.join(ROOT, rel));
    if (!file.startsWith(ROOT + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
      return { status: 404, body: 'Pagina nao encontrada.' };
    }
    const ext = path.extname(file).toLowerCase();
    const { raw, gz } = load(file);
    const useGz = /\bgzip\b/i.test(request.headers.get('accept-encoding') || '');
    const headers = {
      'Content-Type': TYPES[ext] || 'application/octet-stream',
      'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=86400',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'same-origin',
      'X-Frame-Options': 'SAMEORIGIN',
      Vary: 'Accept-Encoding'
    };
    if (useGz) headers['Content-Encoding'] = 'gzip';
    return { status: 200, headers, body: request.method === 'HEAD' ? '' : (useGz ? gz : raw) };
  }
});
