'use strict';
/*
 * Endpoints da API (todos em /api/...).
 * Todos exigem login Medicare + utilizador registado e activo, excepto /api/health.
 */
const { app } = require('@azure/functions');
const { getPool, withTransaction, request, sql, queryJson } = require('../lib/db');
const { HttpError, json, route, readJsonBody } = require('../lib/http');
const { requireUser, platformAuthEnabled, effectiveTeams, projectAccess, actor, ROLE_LABEL } = require('../lib/auth');
const { audit, APP_VERSION } = require('../lib/audit');
const { getProjectPayload, prewarm, listTeams } = require('../lib/projectData');
const zlib = require('zlib');
const { applyChanges, resetProject } = require('../lib/changes');
const users = require('../lib/users');
const plan = require('../lib/planConfig');
const weeks = require('../lib/planWeeks');
const sched = require('../lib/planSchedule');
const absences = require('../lib/planAbsences');
const closing = require('../lib/planClose');
const corr = require('../lib/planCorrections');
const opsLib = require('../lib/planOperators');
const testLib = require('../lib/planTest');

const PID_RE = /^[A-Za-z0-9_-]{1,60}$/;
function pidOf(req) {
  const p = req.params.projectId;
  if (!PID_RE.test(p || '')) throw new HttpError(400, 'PROJECTO_INVALIDO', 'Identificador de projecto invalido.');
  return p;
}
function dateParam(v) {
  if (!v) return null;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) throw new HttpError(400, 'DATA_INVALIDA', 'Datas no formato AAAA-MM-DD.');
  return v;
}
const rq = (p) => request(p);

function publicAccess(a) {
  return {
    projectId: a.projectId, role: a.role, roleLabel: a.roleLabel, isAdmin: a.isAdmin, teamScope: a.teamScope,
    teams: a.teams, modules: a.modules, canImport: a.canImport, canExport: a.canExport,
    canRevertCorrections: a.canRevert, canManageUsers: a.canManageUsers,
    simulatedRole: a.simulatedRole || null, readOnly: !!a.readOnly
  };
}

/* ------------------------------- estado -------------------------------- */
app.http('health', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/health',
  handler: route(async (req) => {
    let database = 'ok';
    try { const pool = await getPool(); await pool.request().query('SELECT 1 AS ok;'); } catch { database = 'indisponivel'; }
    return json({ status: 'ok', version: APP_VERSION, build: require('../../package.json').version, authEnabled: platformAuthEnabled(), database }, 200, req);
  })
});

/* --------------------------- utilizador actual -------------------------- */
app.http('me', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/me',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const pool = await getPool();
    const r = rq(pool);
    r.input('e', sql.NVarChar(256), user.email);
    const res = await r.query(`
      DECLARE @prev datetime2(3) = (SELECT LastLoginAt FROM dbo.AppUsers WHERE UserEmail = @e);
      UPDATE dbo.AppUsers SET LastLoginAt = SYSUTCDATETIME() WHERE UserEmail = @e;
      SELECT @prev AS prev;`);
    const prev = res.recordset?.[0]?.prev;
    if (!prev || (Date.now() - new Date(prev).getTime()) > 30 * 60 * 1000) {
      await audit(pool, actor(user, null), { action: 'LOGIN', entity: 'AppUser', entityId: user.email, detail: 'Inicio de sessao' }, req);
    }
    let offProjects = [];
    try { offProjects = await opsLib.autoDeactivate(pool, user, req); } catch { offProjects = []; }
    const projects = (await users.listProjects(pool, user)).filter((p) => !offProjects.includes(p.projectId));
    /* o projeto de testes nunca é o projeto de arranque nem conta para decidir se há escolha (users.js › pickDefaultProject) */
    const defaultProjectId = users.pickDefaultProject(projects, user.lastProjectId, user.isGlobalAdmin);
    const adm = users.administeredProjects(user);
    if (defaultProjectId) {
      try {
        const acc = projectAccess(user, defaultProjectId);
        const tms = effectiveTeams(acc, '');
        if (!(Array.isArray(tms) && !tms.length)) prewarm(pool, defaultProjectId, { teams: tms });
      } catch { /* sem pre-carregamento */ }
    }
    return json({
      email: user.email, name: user.name, isGlobalAdmin: user.isGlobalAdmin,
      roleLabel: user.isGlobalAdmin ? ROLE_LABEL.ADMIN_GERAL : null,
      projects: projects.map((p) => ({ ...p, roleLabel: ROLE_LABEL[p.role] })),
      defaultProjectId,
      canManageUsers: adm === null || adm.length > 0,
      administeredProjects: adm,
      version: APP_VERSION
    }, 200, req);
  })
});

/* Abrir um projecto: valida o acesso, memoriza-o como ultimo usado e devolve as permissoes. */
app.http('meProject', {
  methods: ['PUT'], authLevel: 'anonymous', route: 'api/me/project',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const body = await readJsonBody(req, 1);
    const projectId = String(body.projectId || '');
    if (!PID_RE.test(projectId)) throw new HttpError(400, 'PROJECTO_INVALIDO', 'Identificador de projecto invalido.');
    const access = projectAccess(user, projectId);
    const pool = await getPool();
    const r = rq(pool);
    r.input('e', sql.NVarChar(256), user.email);
    r.input('pid', sql.VarChar(60), projectId);
    const res = await r.query(`
      IF NOT EXISTS (SELECT 1 FROM dbo.Projects WHERE ProjectId = @pid)
      BEGIN
        SELECT 0 AS ok;
      END
      ELSE
      BEGIN
        UPDATE dbo.AppUsers SET LastProjectId = @pid WHERE UserEmail = @e;
        SELECT 1 AS ok;
      END`);
    if (!res.recordset[0].ok) throw new HttpError(404, 'PROJECTO_INEXISTENTE', 'Projecto nao encontrado.');
    try {
      const tms = effectiveTeams(access, '');
      if (!(Array.isArray(tms) && !tms.length)) prewarm(pool, projectId, { teams: tms });
    } catch { /* sem pre-carregamento */ }
    await audit(pool, actor(user, access), { projectId, action: 'PROJECT_OPEN', entity: 'Project', entityId: projectId, detail: 'Abriu o projecto' }, req);
    return json(publicAccess(access), 200, req);
  })
});

/* ------------------------------ projectos ------------------------------ */
app.http('projectsList', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/projects',
  handler: route(async (req) => {
    const user = await requireUser(req);
    return json(await users.listProjects(await getPool(), user), 200, req);
  })
});

app.http('projectsCreate', {
  methods: ['POST'], authLevel: 'anonymous', route: 'api/projects',
  handler: route(async (req) => {
    const user = await requireUser(req);
    if (!user.isGlobalAdmin) throw new HttpError(403, 'SEM_PERMISSAO', 'So o Administrador Geral pode criar projectos.');
    const body = await readJsonBody(req, 1);
    const projectId = String(body.projectId || '').trim();
    const projectName = String(body.projectName || projectId).trim().slice(0, 200);
    if (!PID_RE.test(projectId)) throw new HttpError(400, 'PROJECTO_INVALIDO', 'Use apenas letras, numeros, - e _ (max. 60).');
    await withTransaction(async (tx) => {
      const r = rq(tx);
      r.input('pid', sql.VarChar(60), projectId);
      r.input('name', sql.NVarChar(200), projectName);
      r.input('user', sql.NVarChar(256), user.email);
      r.input('ver', sql.VarChar(120), String(body.applicationVersion || '').slice(0, 120) || null);
      const res = await r.query(`
        IF EXISTS (SELECT 1 FROM dbo.Projects WHERE ProjectId = @pid)
        BEGIN
          SELECT 0 AS created;
        END
        ELSE
        BEGIN
          INSERT INTO dbo.Projects (ProjectId, ProjectName, SchemaVersion, RulesSchema, ApplicationVersion, CreatedBy)
          VALUES (@pid, @name, '1.1', '2.0-temporal', @ver, @user);
          SELECT 1 AS created;
        END`);
      if (!res.recordset[0].created) throw new HttpError(409, 'PROJECTO_EXISTE', 'Ja existe um projecto com este identificador.');
      await audit(tx, actor(user, null), { projectId, action: 'PROJECT_CREATE', entity: 'Project', entityId: projectId, detail: `Projecto criado: ${projectName}` }, req);
    });
    return json({ projectId, projectName }, 201, req);
  })
});

app.http('projectAccess', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/projects/{projectId}/access',
  handler: route(async (req) => {
    const user = await requireUser(req);
    return json(publicAccess(projectAccess(user, pidOf(req))), 200, req);
  })
});

app.http('projectData', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/projects/{projectId}/data',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const projectId = pidOf(req);
    const access = projectAccess(user, projectId);
    if (access.role === 'OPERADOR') throw new HttpError(403, 'SEM_PERMISSAO', 'Os operadores consultam o seu horário em «O meu horário».');
    const q = req.query;
    const teams = effectiveTeams(access, q.get('team'));
    if (Array.isArray(teams) && !teams.length) throw new HttpError(403, 'SEM_EQUIPA', 'Nao tem equipas atribuidas neste projecto. Contacte a administracao.');
    const payload = await getProjectPayload(await getPool(), projectId, {
      teams, from: dateParam(q.get('from')), to: dateParam(q.get('to'))
    });
    const gzipOk = /\bgzip\b/i.test(req.headers.get('accept-encoding') || '');
    return {
      status: 200,
      headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Data-Version': payload.version },
        gzipOk ? { 'Content-Encoding': 'gzip', Vary: 'Accept-Encoding' } : {}),
      body: gzipOk ? payload.gz : zlib.gunzipSync(payload.gz)
    };
  })
});

app.http('projectTeams', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/projects/{projectId}/teams',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const projectId = pidOf(req);
    const access = projectAccess(user, projectId);
    return json(await listTeams(await getPool(), projectId, access.teamScope === 'ALL' ? null : access.teams), 200, req);
  })
});

/* Gravacao (botao "Guardar"): todas as alteracoes pendentes num unico pedido; inclui importacao. */
app.http('projectChanges', {
  methods: ['POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/changes',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const projectId = pidOf(req);
    const access = projectAccess(user, projectId);
    const body = await readJsonBody(req);
    const result = await withTransaction((tx) => applyChanges(tx, user, access, projectId, body, req));
    return json({ ok: true, result }, 200, req);
  })
});

app.http('projectExportLog', {
  methods: ['POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/export-log',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const projectId = pidOf(req);
    const access = projectAccess(user, projectId);
    if (!access.canExport) throw new HttpError(403, 'SEM_PERMISSAO', 'Nao tem autorizacao para exportar dados.');
    const body = await readJsonBody(req, 1);
    await audit(await getPool(), actor(user, access), {
      projectId, action: 'EXPORT', entity: 'Project', entityId: projectId,
      detail: String(body.what || 'Exportacao').slice(0, 500),
      counts: { rows: Number(body.rows) || 0, format: String(body.format || '').slice(0, 20) }
    }, req);
    return json({ ok: true }, 200, req);
  })
});

/* -------------------------- administracao ------------------------------ */
app.http('adminUsersList', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/admin/users',
  handler: route(async (req) => {
    const user = await requireUser(req);
    return json(await users.listUsers(await getPool(), user), 200, req);
  })
});

/* Dados gerais (nome, activo, Administrador Geral) - so Administrador Geral. Corpo: { email, ... } */
app.http('adminUserSave', {
  methods: ['PUT'], authLevel: 'anonymous', route: 'api/admin/users',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const body = await readJsonBody(req, 1);
    const saved = await withTransaction((tx) => users.saveUserGlobal(tx, user, body.email, body, req));
    return json(saved, 200, req);
  })
});

/* Acesso a um projecto. Corpo: { email, projectId, role, isActive, modules, canImport, canExport, canRevertCorrections, teams, displayName } */
app.http('adminAccessSave', {
  methods: ['PUT'], authLevel: 'anonymous', route: 'api/admin/access',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const body = await readJsonBody(req, 1);
    const projectId = String(body.projectId || '');
    if (!PID_RE.test(projectId)) throw new HttpError(400, 'PROJECTO_INVALIDO', 'Indique o projecto.');
    const saved = await withTransaction((tx) => users.saveProjectAccess(tx, user, body.email, projectId, body, req));
    return json(saved, 200, req);
  })
});

app.http('adminModules', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/admin/modules',
  handler: route(async (req) => {
    const user = await requireUser(req);
    users.requireUserManager(user);
    return json(await users.listModules(await getPool()), 200, req);
  })
});

app.http('adminProjectTeams', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/admin/projects/{projectId}/teams',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const projectId = pidOf(req);
    users.requireProjectAdmin(user, projectId);
    return json(await users.listProjectTeams(await getPool(), projectId), 200, req);
  })
});

app.http('adminAudit', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/admin/audit',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const q = Object.fromEntries(req.query.entries());
    return json(await users.queryAudit(await getPool(), user, q), 200, req);
  })
});

/* Reset aos dados de um projecto (Administrador Geral). Corpo: { confirm, keepSettings, keepRh, keepAttendance, keepRules } */
app.http('adminProjectReset', {
  methods: ['POST'], authLevel: 'anonymous', route: 'api/admin/projects/{projectId}/reset',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const projectId = pidOf(req);
    const body = await readJsonBody(req, 1);
    const result = await withTransaction((tx) => resetProject(tx, user, projectId, body, req));
    return json({ ok: true, result }, 200, req);
  })
});

/* ======================= Ciclo de horarios · Configuracao ======================= */
function notOperator(access) {
  if (access.role === 'OPERADOR') throw new HttpError(403, 'SEM_PERMISSAO', 'Sem acesso a esta pagina.');
}
app.http('planConfig', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/config',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const projectId = pidOf(req);
    const access = projectAccess(user, projectId);
    notOperator(access);
    return json(await plan.getConfig(await getPool(), user, access, projectId), 200, req);
  })
});
app.http('planConfigSave', {
  methods: ['PUT'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/config/{section}',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const projectId = pidOf(req);
    const access = projectAccess(user, projectId);
    const section = String(req.params.section || '');
    const body = await readJsonBody(req, 1);
    const value = await withTransaction((tx) => plan.saveSection(tx, user, access, projectId, section, body.value, req));
    return json({ ok: true, value }, 200, req);
  })
});
app.http('planOperators', {
  methods: ['GET', 'PUT'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/operators',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const projectId = pidOf(req);
    const access = projectAccess(user, projectId);
    notOperator(access);
    if (req.method === 'GET') return json(await plan.listOperators(await getPool(), projectId, access), 200, req);
    const body = await readJsonBody(req, 2);
    const result = await withTransaction((tx) => plan.savePatterns(tx, user, access, projectId, body.items, req));
    return json({ ok: true, result, operators: await plan.listOperators(await getPool(), projectId, access) }, 200, req);
  })
});
app.http('planOperatorsSuggest', {
  methods: ['POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/operators/suggest',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const projectId = pidOf(req);
    const access = projectAccess(user, projectId);
    const result = await withTransaction((tx) => plan.suggestPatterns(tx, user, access, projectId, req));
    return json({ ok: true, result, operators: await plan.listOperators(await getPool(), projectId, access) }, 200, req);
  })
});
app.http('planReasons', {
  methods: ['POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/reasons',
  handler: route(async (req) => {
    const user = await requireUser(req);
    const projectId = pidOf(req);
    const access = projectAccess(user, projectId);
    notOperator(access);
    const body = await readJsonBody(req, 1);
    const result = await withTransaction((tx) => plan.reasonAction(tx, user, access, projectId, body, req));
    return json({ ok: true, result, reasons: await plan.listReasons(await getPool(), projectId) }, 200, req);
  })
});

/* ======================= Ciclo de horarios · Semanas e necessidades (passo 5) ======================= */
app.http('planWeeks', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/weeks',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId); notOperator(access);
    return json(await weeks.listWeeks(await getPool(), user, access, projectId), 200, req);
  })
});
app.http('planWeekNeeds', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/weeks/{week}/needs',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId); notOperator(access);
    const w = String(req.params.week || ''); if (!weeks.WEEK_RE.test(w)) throw new HttpError(400, 'SEMANA_INVALIDA', 'Semana inválida.');
    return json(await weeks.getNeeds(await getPool(), user, access, projectId, w), 200, req);
  })
});
app.http('planWeekCompare', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/weeks/{week}/compare',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId); notOperator(access);
    const w = String(req.params.week || ''); if (!weeks.WEEK_RE.test(w)) throw new HttpError(400, 'SEMANA_INVALIDA', 'Semana inválida.');
    return json(await weeks.compareWeek(await getPool(), user, access, projectId, w), 200, req);
  })
});
app.http('planWeekIntegrate', {
  methods: ['POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/weeks/{week}/integrate',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId);
    const w = String(req.params.week || ''); if (!weeks.WEEK_RE.test(w)) throw new HttpError(400, 'SEMANA_INVALIDA', 'Semana inválida.');
    const result = await withTransaction((tx) => weeks.integrateWeek(tx, user, access, projectId, w, req));
    return json({ ok: true, result }, 200, req);
  })
});
app.http('planWeekReintegrate', {
  methods: ['POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/weeks/{week}/reintegrate',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId);
    const w = String(req.params.week || ''); if (!weeks.WEEK_RE.test(w)) throw new HttpError(400, 'SEMANA_INVALIDA', 'Semana inválida.');
    const body = await readJsonBody(req, 1);
    const result = await withTransaction((tx) => weeks.reintegrateWeek(tx, user, access, projectId, w, body, req));
    return json({ ok: true, result }, 200, req);
  })
});

/* ======================= Ciclo de horarios · Horarios da semana (passo 6) ======================= */
app.http('planSchedule', {
  methods: ['GET', 'PUT'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/weeks/{week}/schedule',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId); notOperator(access);
    const w = String(req.params.week || ''); if (!weeks.WEEK_RE.test(w)) throw new HttpError(400, 'SEMANA_INVALIDA', 'Semana inválida.');
    if (req.method === 'GET') return json(await sched.getSchedule(await getPool(), user, access, projectId, w), 200, req);
    const body = await readJsonBody(req, 8);
    const result = await withTransaction((tx) => sched.saveSchedule(tx, user, access, projectId, w, body, req));
    return json({ ok: true, result, schedule: await sched.getSchedule(await getPool(), user, access, projectId, w) }, 200, req);
  })
});
app.http('planJustify', {
  methods: ['POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/weeks/{week}/justifications',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId); notOperator(access);
    const w = String(req.params.week || ''); if (!weeks.WEEK_RE.test(w)) throw new HttpError(400, 'SEMANA_INVALIDA', 'Semana inválida.');
    const body = await readJsonBody(req, 1);
    const result = await withTransaction((tx) => sched.justify(tx, user, access, projectId, w, body, req));
    return json({ ok: true, result, schedule: await sched.getSchedule(await getPool(), user, access, projectId, w) }, 200, req);
  })
});

/* ======================= Ausencias do colaborador (ficha) · 1.7.1 ======================= */
app.http('planAbsences', {
  methods: ['GET', 'POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/absences',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId); notOperator(access);
    if (req.method === 'GET') return json(await absences.listAbsences(await getPool(), user, access, projectId, new URL(req.url).searchParams), 200, req);
    const body = await readJsonBody(req, 1);
    const fn = body.action === 'delete' ? absences.removeAbsence : absences.addAbsence;
    const result = await withTransaction((tx) => fn(tx, user, access, projectId, body, req));
    return json({ ok: true, result }, 200, req);
  })
});

/* ======================= Ciclo de horarios · Fecho e publicacao (passo 7) ======================= */
app.http('planClose', {
  methods: ['GET', 'POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/weeks/{week}/close',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId); notOperator(access);
    const w = String(req.params.week || ''); if (!weeks.WEEK_RE.test(w)) throw new HttpError(400, 'SEMANA_INVALIDA', 'Semana inválida.');
    if (req.method === 'GET') return json(await closing.getClose(await getPool(), user, access, projectId, w), 200, req);
    const body = await readJsonBody(req, 1);
    const result = await withTransaction((tx) => closing.closeAction(tx, user, access, projectId, w, body, req));
    return json({ ok: true, result }, 200, req);
  })
});
app.http('planWeekView', {
  methods: ['POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/weeks/{week}/view',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId);
    const w = String(req.params.week || ''); if (!weeks.WEEK_RE.test(w)) throw new HttpError(400, 'SEMANA_INVALIDA', 'Semana inválida.');
    let ack = false; try { const b = await req.json(); ack = !!(b && b.ack); } catch { ack = false; }
    if (ack && access.role === 'OPERADOR' && req.headers.get('x-act-as')) ack = false;
    return json(await withTransaction((tx) => closing.recordView(tx, user, access, projectId, w, req, ack)), 200, req);
  })
});
app.http('planAnnouncements', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/announcements',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId);
    return json(await closing.announcements(await getPool(), user, access, projectId), 200, req);
  })
});

/* ======================= Ciclo de horarios · Correcoes de horas (passo 8A) ======================= */
app.http('planCorrections', {
  methods: ['GET', 'POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/corrections',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId); notOperator(access);
    if (req.method === 'GET') return json(await corr.listCorrections(await getPool(), user, access, projectId, new URL(req.url).searchParams), 200, req);
    const body = await readJsonBody(req, 2);
    const fn = body.action === 'approve' || body.action === 'reject' ? corr.decide : body.action === 'agent-save' ? corr.saveAgentCorrection : body.action === 'bulk-confirm' ? corr.bulkConfirm : corr.createCorrections;
    const result = await withTransaction((tx) => fn(tx, user, access, projectId, body, req));
    return json({ ok: true, result }, 200, req);
  })
});

/* ======================= Operadores (passo 8B) ======================= */
app.http('meSchedule', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/projects/{projectId}/me/schedule',
  handler: route(async (req) => {
    const user0 = await requireUser(req); const projectId = pidOf(req); const access0 = projectAccess(user0, projectId);
    const pool = await getPool();
    const { user, access } = await opsLib.actingAs(pool, req, user0, access0, projectId);
    const data = await opsLib.mySchedule(pool, user, access, projectId);
    if (access.simulatedBy) data.simulation = { by: access.simulatedBy };
    return json(data, 200, req);
  })
});
app.http('meRequests', {
  methods: ['POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/me/requests',
  handler: route(async (req) => {
    const user0 = await requireUser(req); const projectId = pidOf(req); const access0 = projectAccess(user0, projectId);
    const body = await readJsonBody(req, 1);
    return json({ ok: true, result: await withTransaction(async (tx) => { const { user, access } = await opsLib.actingAs(tx, req, user0, access0, projectId); return opsLib.myRequest(tx, user, access, projectId, body, req); }) }, 200, req);
  })
});
app.http('teamRequests', {
  methods: ['GET', 'POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/team-requests',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId); notOperator(access);
    if (req.method === 'GET') return json(await opsLib.listTeamRequests(await getPool(), user, access, projectId), 200, req);
    const body = await readJsonBody(req, 1);
    return json({ ok: true, result: await withTransaction((tx) => opsLib.decideTeamRequests(tx, user, access, projectId, body, req)) }, 200, req);
  })
});
app.http('operatorsAccess', {
  methods: ['GET', 'POST'], authLevel: 'anonymous', route: 'api/admin/projects/{projectId}/operators-access',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId);
    if (req.method === 'GET') return json(await opsLib.operatorCandidates(await getPool(), user, access, projectId), 200, req);
    const body = await readJsonBody(req, 1);
    return json({ ok: true, result: await withTransaction((tx) => opsLib.createOperatorAccess(tx, user, access, projectId, body, req)) }, 200, req);
  })
});

/* ======================= Projeto de testes ======================= */
/* rota principal fora de /api/admin (evita qualquer conflito com rotas de administracao da plataforma) */
async function testHandler(req) {
  const user = await requireUser(req); const projectId = pidOf(req);
  if (req.method === 'GET') { let a = null; try { a = projectAccess(user, projectId); } catch { a = null; } return json(await testLib.testStatus(await getPool(), user, projectId, a), 200, req); }
  const body = await readJsonBody(req, 1);
  return json({ ok: true, result: await withTransaction((tx) => testLib.copyToTest(tx, user, projectId, body, req)) }, 200, req);
}
app.http('testEnvironment', { methods: ['GET', 'POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/test-environment', handler: route(testHandler) });
app.http('testProject', { methods: ['GET', 'POST'], authLevel: 'anonymous', route: 'api/admin/projects/{projectId}/test', handler: route(testHandler) });

app.http('planMemberSummary', {
  methods: ['GET'], authLevel: 'anonymous', route: 'api/projects/{projectId}/plan/member-summary',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId); notOperator(access);
    return json(await opsLib.memberSummary(await getPool(), user, access, projectId, new URL(req.url).searchParams.get('member') || ''), 200, req);
  })
});

/* ======================= Desempenho (fase 1, M1) ======================= */
app.http('planPerfReport', {
  methods: ['POST'], authLevel: 'anonymous', route: 'api/projects/{projectId}/perf-report',
  handler: route(async (req) => {
    const user = await requireUser(req); const projectId = pidOf(req); const access = projectAccess(user, projectId);
    if (!access.isAdmin) throw new HttpError(403, 'SEM_PERMISSAO', 'Só os Administradores guardam medições.');
    const body = await readJsonBody(req, 1);
    const rows = Array.isArray(body.rows) ? body.rows.slice(0, 60) : [];
    const pool = await getPool();
    await audit(pool, { email: user.email, name: user.name, type: access.role }, { projectId, action: 'PERF_REPORT', entity: 'Performance', entityId: String(body.build || ''),
      detail: `Medições do browser: ${Number(body.samples) || 0} pedidos; arranque até ao Início ${body.boot && body.boot.home ? Math.round(body.boot.home) + ' ms' : '—'}.`,
      counts: { boot: body.boot || {}, rows } }, req);
    return json({ ok: true }, 200, req);
  })
});
