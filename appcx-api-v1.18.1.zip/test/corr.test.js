'use strict';
/* Correções de horas: prazos, feriados e correção por agente (popup) com base de dados simulada em memória. */
const assert = require('assert');
process.env.APPCX_TODAY = process.env.APPCX_TODAY || '2026-10-21'; /* «hoje» fixo para os testes */
const path = require('path');
const dbPath = path.resolve(__dirname, '../src/lib/db.js');
const realDb = require(dbPath);
const DB = {};
function resetDb() {
  DB.week = { State: 'PUBLICADA', Version: 1, WeekStart: '2026-10-19' };
  DB.shifts = [
    { id: 'P|ana|2026-10-19', member: 'Ana', team: 't1', date: '2026-10-19', start: '09:00', end: '18:00', code: 'WORK', breakMin: 60, ad: 'Almoço: 13h-14h P', week: '2026-S43', extra: '{"src":"PROPOSTA"}', rowVer: '0x01', pStart: '09:00', pEnd: '18:00', pCode: null, pMember: 'Ana' },
    { id: 'P|ana|2026-10-20', member: 'Ana', team: 't1', date: '2026-10-20', start: '09:00', end: '18:00', code: 'WORK', breakMin: 60, ad: 'Almoço: 13h-14h R', week: '2026-S43', extra: '{"src":"PROPOSTA"}', rowVer: '0x02', pStart: '09:00', pEnd: '18:00', pCode: null, pMember: 'Ana' },
    { id: 'P|rui|2026-10-19', member: 'Rui', team: 't2', date: '2026-10-19', start: '11:00', end: '20:00', code: 'WORK', breakMin: 60, ad: 'Almoço: 15h-16h P', week: '2026-S43', extra: '{"src":"PROPOSTA"}', rowVer: '0x03', pStart: '11:00', pEnd: '20:00', pCode: null, pMember: 'Rui' }];
  DB.requests = []; DB.shiftCorr = []; DB.audit = []; DB.writes = []; DB.nextId = 100; DB.rv = 10;
}
const reasons = [{ ReasonId: 1, Name: 'Atraso', Status: 'VALIDADO', RequiresNote: 0 }, { ReasonId: 2, Name: 'Outro', Status: 'VALIDADO', RequiresNote: 1 }];
function fakeRequest() {
  const inp = {};
  return { input(k, t, v) { inp[k] = v; return this; }, async query(q) {
    if (/sp_getapplock/.test(q)) return { recordset: [] };
    if (/FROM dbo\.PlanWeeks/.test(q)) return { recordset: DB.week ? [DB.week] : [] };
    if (/FROM dbo\.Reasons/.test(q)) return { recordset: reasons.filter((r) => r.ReasonId === Number(inp.rid)) };
    if (/INSERT INTO dbo\.Requests/.test(q)) { const id = DB.nextId++; DB.requests.push({ id, status: 'APROVADO', week: inp.w, member: inp.m, day: String(inp.d), reasonId: inp.rid, payload: inp.p, shiftId: inp.sid, note: inp.n, by: inp.user }); DB.writes.push('Requests'); return { recordset: [{ id }] }; }
    if (/UPDATE dbo\.Shifts SET E_StartTime/.test(q)) { const s = DB.shifts.find((x) => x.id === inp.id); s.start = inp.st; s.end = inp.en; s.code = inp.lab || 'WORK'; s.ad = inp.ad; s.breakMin = inp.br; s.rowVer = '0x' + (DB.rv++); DB.writes.push('Shifts'); return { recordset: [] }; }
    if (/UPDATE dbo\.Shifts SET E_Label = 'FL'/.test(q)) { const s = DB.shifts.find((x) => x.id === inp.id); s.code = 'FL'; s.rowVer = '0x' + (DB.rv++); DB.writes.push('Shifts'); return { recordset: [] }; }
    if (/INSERT INTO dbo\.Shifts/.test(q)) { DB.shifts.push({ id: inp.id, member: inp.m, team: inp.team, date: String(inp.d), start: inp.st, end: inp.en, code: inp.lab || 'WORK', breakMin: inp.br, ad: inp.ad, week: inp.w, extra: inp.ex, rowVer: '0x' + (DB.rv++) }); DB.writes.push('Shifts+'); return { recordset: [] }; }
    if (/UPDATE dbo\.Requests SET ShiftId/.test(q)) { const r = DB.requests.find((x) => x.id === Number(inp.rid)); if (r) r.shiftId = inp.id; return { recordset: [] }; }
    if (/INSERT INTO dbo\.ShiftCorrections/.test(q)) { JSON.parse(inp.j).forEach((f) => DB.shiftCorr.push({ shiftId: inp.sid, ...f, rule: inp.rule, key: inp.key })); DB.writes.push('ShiftCorrections'); return { recordset: [] }; }
    if (/UPDATE dbo\.Projects/.test(q)) { DB.writes.push('Projects'); return { recordset: [] }; }
    if (/INSERT INTO dbo\.AuditLog/.test(q)) { DB.audit.push({ action: inp.Action, detail: inp.Detail, entityId: inp.EntityId }); DB.writes.push('Audit'); return { recordset: [] }; }
    throw new Error('consulta não simulada: ' + q.slice(0, 80));
  }, _inp: inp };
}
async function fakeQueryJson(r, q) {
  const inp = r._inp;
  if (/FROM dbo\.Shifts s WHERE s\.ProjectId/.test(q)) {
    return DB.shifts.filter((x) => x.member === inp.m && (inp.w ? x.week === inp.w : (x.date >= String(inp.d0) && x.date <= String(inp.d1)))).map((x) => ({ ...x }));
  }
  if (/FROM dbo\.Requests WHERE ProjectId = @pid AND Type = 'CORRECTION' AND Week = @w AND TargetEmail = @m/.test(q)) {
    return DB.requests.filter((x) => x.week === inp.w && x.member === inp.m && String(x.day) === String(inp.d) && ['APROVADO', 'PARA_REVER', 'PENDENTE'].includes(x.status))
      .map((x) => ({ id: x.id, status: x.status, reasonId: x.reasonId, setKey: (JSON.parse(x.payload || '{}') || {}).setKey || null }));
  }
  if (/E_Label IN \('AD','DA'\)/.test(q)) return [];
  throw new Error('consulta JSON não simulada: ' + q.slice(0, 80));
}
require.cache[dbPath].exports = { ...realDb, request: fakeRequest, queryJson: fakeQueryJson, getPool: async () => ({}) };
const planConfig = require('../src/lib/planConfig');
planConfig.listOperators = async () => [{ member: 'Ana', team: 't1' }, { member: 'Rui', team: 't2' }];
planConfig.readSettings = async () => ({ limits: planConfig.DEFAULTS.limits, deviation: planConfig.DEFAULTS.deviation, holidays: { items: [] } });
require('../src/lib/planSchedule').lockDa = async () => {};
const C = require('../src/lib/planCorrections');

/* --- prazos --- */
assert.strictEqual(C.deadlineFor('2026-09-21', 5), '2026-10-07');
assert.strictEqual(C.deadlineFor('2026-10-30', 5), '2026-11-06');
assert.strictEqual(C.deadlineFor('2026-12-15', 5), '2027-01-07');
console.log('3 testes das correções passaram');
(() => {
  const hol = planConfig.DEFAULTS.holidays.items;
  assert.strictEqual(C.deadlineFor('2026-09-30', 5, hol), '2026-10-08');
  assert.strictEqual(C.deadlineFor('2026-11-20', 5, hol), '2026-12-09');
  assert.strictEqual(C.deadlineFor('2026-09-30', 5, []), '2026-10-07');
  assert.throws(() => planConfig.validateSection('holidays', { items: [{ date: '2026-02-30', name: 'x' }] }, {}));
  console.log('4 testes dos feriados passaram');
})();

/* --- correção por agente (sempre diária) --- */
const admin = { isAdmin: true, role: 'PROJECT_ADMIN', teamScope: 'ALL' };
const sup = { isAdmin: false, role: 'SUPERVISOR', teamScope: 'TEAMS', teams: ['t1'] };
const user = { email: 'magda@medicare.pt', name: 'Magda' };
const day = (date, over) => { const s = DB.shifts.find((x) => x.member === (over.member || 'Ana') && x.date === date && x.code === 'WORK') || DB.shifts.find((x) => x.member === (over.member || 'Ana') && x.date === date);
  return { date, shiftId: s ? s.id : null, rowVer: s ? s.rowVer : null, code: 'WORK', start: s ? s.start : '09:00', end: s ? s.end : '18:00', lunch: 13, presence: s && /R$/.test(s.ad) ? 'R' : 'P', ...over, member: undefined }; };
const save = (acc, body) => C.saveAgentCorrection({}, user, acc, 'P', { action: 'agent-save', week: '2026-S43', member: 'Ana', baseId: 0, ...body }, null);
const noWrites = async (fn, re) => { const n = DB.writes.length; await assert.rejects(fn, re); assert.strictEqual(DB.writes.length, n, 'nada pode ser escrito'); };
(async () => {
  let n = 0; const t = async (name, f) => { resetDb(); await f(); n++; };
  await t('núcleo: normalização e comparação', async () => {
    assert.ok(C.sameDay(C.normDay({ code: 'WORK', start: '09:00', end: '18:00', lunch: 13, presence: 'P' }), { code: 'WORK', start: '09:00', end: '18:00', lunch: 13, presence: 'P' }));
    assert.ok(!C.sameDay(C.normDay({ code: 'WORK', start: '09:30', end: '18:00', lunch: 13, presence: 'P' }), { code: 'WORK', start: '09:00', end: '18:00', lunch: 13, presence: 'P' }));
    assert.strictEqual(C.normDay({ code: '' }), null);
  });
  await t('gravação inicial aplica de imediato ao horário publicado', async () => {
    const r = await save(admin, { reasonId: 1, days: [day('2026-10-19', { start: '09:30' })] });
    assert.strictEqual(r.mode, 'INITIAL'); assert.strictEqual(r.changed, 1);
    assert.strictEqual(DB.shifts[0].start, '09:30', 'efetivo corrigido');
    assert.strictEqual(DB.shifts[0].pStart, '09:00', 'planeado intacto');
    assert.strictEqual(DB.requests.length, 1); assert.strictEqual(DB.requests[0].status, 'APROVADO');
    assert.deepStrictEqual(DB.shiftCorr.map((x) => x.field), ['start']);
    assert.strictEqual(DB.audit[0].action, 'CORRECTION_APPLY');
    assert.ok(DB.writes.includes('Projects'), 'cache dos indicadores invalidada');
    assert.strictEqual(DB.week.State, 'PUBLICADA');
  });
  await t('supervisor: aplica sem aprovação, só na sua equipa', async () => {
    const r = await save(sup, { reasonId: 1, days: [day('2026-10-19', { start: '09:15' })] });
    assert.strictEqual(r.mode, 'INITIAL'); assert.strictEqual(DB.requests[0].status, 'APROVADO');
    await noWrites(() => save(sup, { member: 'Rui', reasonId: 1, days: [day('2026-10-19', { member: 'Rui', start: '11:30' })] }), /fora das suas equipas/);
  });
  await t('cada agente tem o seu horário: corrigir a Ana não toca no Rui', async () => {
    await save(admin, { reasonId: 1, days: [day('2026-10-19', { start: '10:00' })] });
    assert.strictEqual(DB.shifts[2].start, '11:00');
  });
  await t('motivo obrigatório na primeira correção com alterações', async () => {
    await noWrites(() => save(admin, { days: [day('2026-10-19', { start: '09:30' })] }), /motivo/);
  });
  await t('falha de regras não deixa nada aplicado (mais de 10 h)', async () => {
    await noWrites(() => save(admin, { reasonId: 1, days: [day('2026-10-19', { start: '08:00', end: '20:00' })] }), /regras de limite/);
    assert.strictEqual(DB.shifts[0].start, '09:00');
  });
  await t('horas inválidas recusadas sem escrita', async () => {
    await noWrites(() => save(admin, { reasonId: 1, days: [day('2026-10-19', { start: '18:00', end: '09:00' })] }), /horas inválidas/);
  });
  await t('conflito: registo alterado por outra pessoa (RowVer)', async () => {
    await noWrites(() => save(admin, { reasonId: 1, days: [day('2026-10-19', { start: '09:30', rowVer: '0xOLD' })] }), /alterado por outra pessoa/);
  });
  await t('conflito e duplicado: segunda gravação com a mesma base é recusada', async () => {
    const body = { reasonId: 1, days: [day('2026-10-19', { start: '09:30' })] };
    await save(admin, body);
    await noWrites(() => save(admin, body), /alterada por outra pessoa/);
    assert.strictEqual(DB.requests.length, 1, 'sem duplicados');
  });
  await t('revisão: exige justificação, aplica e preserva o anterior', async () => {
    const r1 = await save(admin, { reasonId: 1, days: [day('2026-10-19', { start: '09:30' })] });
    await noWrites(() => save(admin, { baseId: r1.baseId, days: [day('2026-10-19', { start: '09:45' })] }), /justificação/);
    await noWrites(() => save(admin, { baseId: r1.baseId, justification: '   ', days: [day('2026-10-19', { start: '09:45' })] }), /justificação/);
    const r2 = await save(admin, { baseId: r1.baseId, justification: 'Registo de picagem corrigido', days: [day('2026-10-19', { start: '09:45' })] });
    assert.strictEqual(r2.mode, 'REVISION'); assert.strictEqual(r2.rev, 2);
    assert.strictEqual(DB.shifts[0].start, '09:45');
    assert.strictEqual(DB.requests.length, 2, 'a correção anterior fica guardada');
    const p1 = JSON.parse(DB.requests[0].payload), p2 = JSON.parse(DB.requests[1].payload);
    assert.strictEqual(p1.after.start, '09:30'); assert.strictEqual(p2.before.start, '09:30'); assert.strictEqual(p2.after.start, '09:45');
    assert.strictEqual(p2.justification, 'Registo de picagem corrigido'); assert.strictEqual(DB.requests[1].note, 'Registo de picagem corrigido');
    assert.strictEqual(DB.requests[1].reasonId, 1, 'mantém o motivo anterior');
    assert.strictEqual(DB.audit[1].action, 'CORRECTION_REVISE'); assert.ok(/Justificação: Registo de picagem/.test(DB.audit[1].detail));
  });
  await t('revisão sem alterações não cria revisão', async () => {
    const r1 = await save(admin, { reasonId: 1, days: [day('2026-10-19', { start: '09:30' })] });
    const n0 = DB.writes.length;
    const r2 = await save(admin, { baseId: r1.baseId, days: [day('2026-10-19', {})] });
    assert.strictEqual(r2.mode, 'UNCHANGED'); assert.strictEqual(DB.writes.length, n0); assert.strictEqual(DB.requests.length, 1);
  });
  await t('confirmar sem alterações regista o dia do agente como corrigido', async () => {
    const r = await save(admin, { days: [day('2026-10-19', {})] });
    assert.strictEqual(r.mode, 'CONFIRM'); assert.strictEqual(DB.requests.length, 1);
    assert.strictEqual(JSON.parse(DB.requests[0].payload).kind, 'CONFIRM');
    assert.ok(!DB.writes.includes('Shifts'), 'o horário não muda');
    assert.strictEqual(DB.audit[0].action, 'CORRECTION_CONFIRM');
  });
  await t('semana não publicada: recusa sem escrita', async () => {
    DB.week.State = 'EM_AJUSTE';
    await noWrites(() => save(admin, { reasonId: 1, days: [day('2026-10-19', { start: '09:30' })] }), /semanas publicadas/);
  });
  await t('correção por validar no mesmo dia bloqueia o popup', async () => {
    DB.requests.push({ id: 1, status: 'PENDENTE', week: '2026-S43', member: 'Ana', day: '2026-10-19', payload: '{}' });
    await noWrites(() => save(admin, { reasonId: 1, days: [day('2026-10-19', { start: '09:30' })] }), /por validar/);
  });
  await t('falta (FL) e depois revisão volta a trabalho no mesmo registo', async () => {
    const r1 = await save(admin, { reasonId: 1, days: [day('2026-10-20', { code: 'FL' })] });
    assert.strictEqual(DB.shifts[1].code, 'FL');
    const s = DB.shifts[1];
    const r2 = await save(admin, { baseId: r1.baseId, justification: 'Afinal veio trabalhar', days: [{ date: '2026-10-20', shiftId: s.id, rowVer: s.rowVer, code: 'WORK', start: '09:00', end: '18:00', lunch: 13, presence: 'R' }] });
    assert.strictEqual(r2.mode, 'REVISION'); assert.strictEqual(DB.shifts[1].code, 'WORK');
    assert.strictEqual(DB.shifts.filter((x) => x.member === 'Ana' && x.date === '2026-10-20').length, 1, 'sem registo duplicado');
  });
  await t('a correção é sempre de um dia: vários dias são recusados', async () => {
    await noWrites(() => save(admin, { reasonId: 1, days: [day('2026-10-19', { start: '09:30' }), day('2026-10-20', { start: '09:30' })] }), /sempre de um dia/);
    await noWrites(() => save(admin, { reasonId: 1, days: [] }), /sempre de um dia/);
  });
  await t('cada dia é independente: corrigir outro dia não é revisão nem pede justificação', async () => {
    DB.requests.push({ id: 1, status: 'APROVADO', week: '2026-S43', member: 'Ana', day: '2026-10-19', payload: '{"setKey":"S1","kind":"INITIAL"}', reasonId: 1 });
    const r = await save(admin, { reasonId: 1, days: [day('2026-10-20', { start: '09:30' })] });
    assert.strictEqual(r.mode, 'INITIAL');
    await noWrites(() => save(admin, { baseId: 0, days: [day('2026-10-19', { start: '09:40' })] }), /alterada por outra pessoa/);
    const r2 = await save(admin, { baseId: 1, justification: 'Ajuste', days: [day('2026-10-19', { start: '09:40' })] });
    assert.strictEqual(r2.mode, 'REVISION');
  });
  await t('correção por validar noutro dia não bloqueia este dia', async () => {
    DB.requests.push({ id: 1, status: 'PENDENTE', week: '2026-S43', member: 'Ana', day: '2026-10-20', payload: '{}' });
    const r = await save(admin, { reasonId: 1, days: [day('2026-10-19', { start: '09:30' })] });
    assert.strictEqual(r.mode, 'INITIAL');
  });
  await t('dia futuro não se corrige', async () => {
    DB.shifts.push({ id: 'P|ana|2026-10-23', member: 'Ana', team: 't1', date: '2026-10-23', start: '09:00', end: '18:00', code: 'WORK', breakMin: 60, ad: 'Almoço: 13h-14h P', week: '2026-S43', extra: '{}', rowVer: '0x09', pMember: 'Ana' });
    await noWrites(() => save(admin, { reasonId: 1, days: [day('2026-10-23', { start: '09:30' })] }), /já aconteceram/);
  });
  await t('lote sem alterações: confirma vários agentes de uma vez', async () => {
    const r = await C.bulkConfirm({}, user, admin, 'P', { date: '2026-10-19', members: ['Ana', 'Rui'] }, null);
    assert.strictEqual(r.confirmed, 2);
    assert.deepStrictEqual(DB.requests.map((x) => [x.member, JSON.parse(x.payload).kind, x.day]), [['Ana', 'CONFIRM', '2026-10-19'], ['Rui', 'CONFIRM', '2026-10-19']]);
    assert.ok(!DB.writes.includes('Shifts'), 'o horário não muda');
    assert.deepStrictEqual(DB.audit.map((x) => x.action), ['CORRECTION_CONFIRM', 'CORRECTION_CONFIRM']);
  });
  await t('lote: um agente já corrigido nesse dia → nada é registado', async () => {
    await save(admin, { member: 'Rui', reasonId: 1, days: [day('2026-10-19', { member: 'Rui', start: '11:30' })] });
    const n0 = DB.requests.length;
    await assert.rejects(() => C.bulkConfirm({}, user, admin, 'P', { date: '2026-10-19', members: ['Ana', 'Rui'] }, null), /Rui: .*Nada foi registado/);
    /* a base de dados real desfaz a transação; aqui confirma-se que o erro chega antes do fim do lote */
    assert.ok(DB.requests.length - n0 <= 1);
  });
  await t('lote: supervisor só na sua equipa (o lote é recusado)', async () => {
    await assert.rejects(() => C.bulkConfirm({}, user, sup, 'P', { date: '2026-10-19', members: ['Rui'] }, null), /fora das suas equipas/);
    assert.strictEqual(DB.requests.length, 0);
  });
  await t('lote: dia futuro e lista vazia recusados', async () => {
    await assert.rejects(() => C.bulkConfirm({}, user, admin, 'P', { date: '2026-10-23', members: ['Ana'] }, null), /já aconteceram/);
    await assert.rejects(() => C.bulkConfirm({}, user, admin, 'P', { date: '2026-10-19', members: [] }, null), /Selecione/);
  });
  await t('dias para corrigir: só até hoje, com prazo e contagens', async () => {
    const set = { deviation: { correctionDeadlineWorkday: 5 }, holidays: { items: [] } };
    const sched = [{ date: '2026-10-19', week: '2026-S43', scheduled: 10 }, { date: '2026-10-22', week: '2026-S43', scheduled: 9 }, { date: '2026-08-03', week: '2026-S32', scheduled: 8 }];
    const corr = [{ date: '2026-10-19', corrected: 4, pending: 1 }];
    const sup0 = C.buildCorrectionDays(sched, corr, set, '2026-10-21', false);
    assert.deepStrictEqual(sup0.map((d) => d.date), ['2026-10-19'], 'sem dias futuros nem fora do prazo para quem não é Administrador');
    assert.strictEqual(sup0[0].toCorrect, 6); assert.strictEqual(sup0[0].pending, 1); assert.strictEqual(sup0[0].open, true);
    const adm0 = C.buildCorrectionDays(sched, corr, set, '2026-10-21', true);
    assert.deepStrictEqual(adm0.map((d) => [d.date, d.open]), [['2026-10-19', true], ['2026-08-03', false]]);
  });
  await t('perfil sem permissão', async () => {
    await noWrites(() => save({ isAdmin: false, role: 'UTILIZADOR', teamScope: 'ALL' }, { reasonId: 1, days: [day('2026-10-19', { start: '09:30' })] }), /Só Supervisores/);
  });
  console.log(n + ' testes da correção por agente passaram');
})().catch((e) => { console.error(e); process.exit(1); });
