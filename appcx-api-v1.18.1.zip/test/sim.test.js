'use strict';
/* Simulação de perfil (API 1.18.0): Supervisor e Administrador Geral, só no projeto de testes e só para Administradores */
const assert = require('assert');
const auth = require('../src/lib/auth');
let n = 0; const t = (name, f) => { f(); n++; };
const P = 'TEAMSHIFT_SAC', T = 'TEAMSHIFT_SAC_TESTE';
const acc = (pid, role) => auth.buildAccess({ ProjectId: pid, Role: role, IsActive: 1 }, [], []);
const sim = (role, team) => ({ role, team: team || '', testProjects: new Set([T]), realGlobal: false });
const pa = (s) => ({ email: 'magda@medicare.pt', isGlobalAdmin: false, projects: { [P]: acc(P, 'PROJECT_ADMIN'), [T]: acc(T, 'PROJECT_ADMIN') }, sim: s });

t('Administrador de Projeto simula Supervisor no projeto de testes', () => {
  const a = auth.projectAccess(pa(sim('SUPERVISOR', 'carolina.varela@medicare.pt')), T);
  assert.strictEqual(a.role, 'SUPERVISOR'); assert.strictEqual(a.isAdmin, false);
  assert.strictEqual(a.teamScope, 'ASSIGNED'); assert.deepStrictEqual(a.teams, ['carolina.varela@medicare.pt']);
  assert.ok(!a.canImport && !a.canRevert && !a.canManageUsers);
  assert.strictEqual(auth.effectiveTeams(a, '').length, 1);
});
t('Administrador de Projeto simula Administrador Geral: só consulta', () => {
  const a = auth.projectAccess(pa(sim('ADMIN_GERAL')), T);
  assert.strictEqual(a.role, 'ADMIN_GERAL'); assert.strictEqual(a.readOnly, true); assert.strictEqual(a.simulatedRole, 'ADMIN_GERAL');
});
t('simulação recusada na produção', () => {
  assert.throws(() => auth.projectAccess(pa(sim('SUPERVISOR', 'x')), P), (e) => e.code === 'SO_EM_TESTES');
});
t('Supervisor real não pode simular', () => {
  const u = { email: 's@medicare.pt', isGlobalAdmin: false, projects: { [T]: acc(T, 'SUPERVISOR') }, sim: sim('ADMIN_GERAL') };
  assert.throws(() => auth.projectAccess(u, T), (e) => e.code === 'SEM_PERMISSAO');
});
t('Administrador Geral real a simular Supervisor fica com o perfil de Supervisor', () => {
  const u = { email: 'jorge.tavares@medicare.pt', isGlobalAdmin: false, projects: {}, sim: { ...sim('SUPERVISOR', 'equipa'), realGlobal: true } };
  const a = auth.projectAccess(u, T);
  assert.strictEqual(a.role, 'SUPERVISOR'); assert.strictEqual(a.isAdmin, false);
});
t('sem simulação nada muda', () => {
  const a = auth.projectAccess(pa(undefined), T);
  assert.strictEqual(a.role, 'PROJECT_ADMIN'); assert.strictEqual(a.isAdmin, true);
});

/* cabeçalhos: validação antes de qualquer consulta à base de dados */
const req = (method, url, h) => ({ method, url, headers: { get: (k) => h[k.toLowerCase()] ?? null } });
const run = async (r) => { try { await auth.readSimulation(r, null, { name: 'Magda', isGlobalAdmin: false }); return null; } catch (e) { return e.code || e.message; } };
(async () => {
  assert.strictEqual(await run(req('GET', 'https://x/api/me', { 'x-sim-role': 'DONO' })), 'SIMULACAO_INVALIDA'); n++;
  assert.strictEqual(await run(req('GET', 'https://x/api/me', { 'x-sim-role': 'SUPERVISOR' })), 'SIMULACAO_INVALIDA'); n++;
  assert.strictEqual(await run(req('PUT', 'https://x/api/projects/T/plan/weeks/2026-S44/schedule', { 'x-sim-role': 'ADMIN_GERAL' })), 'SIMULACAO_SO_LEITURA'); n++;
  assert.strictEqual(await run(req('PUT', 'https://x/api/admin/access', { 'x-sim-role': 'SUPERVISOR', 'x-sim-team': 'eq' })), 'SIMULACAO_SEM_ADMINISTRACAO'); n++;
  assert.strictEqual(await run(req('GET', 'https://x/api/me', {})), null); n++;
  console.log(n + ' testes da simulação de perfil passaram');
})().catch((e) => { console.error(e); process.exit(1); });
