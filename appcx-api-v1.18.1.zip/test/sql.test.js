'use strict';
/* Verificação estática das consultas SQL (sem base de dados).
 * O SQL Server recusa subconsultas dentro de funções de agregação (erro 130: COUNT/SUM/... com SELECT dentro). */
const fs = require('fs');
const path = require('path');
const dir = path.resolve(__dirname, '../src/lib');
let checked = 0; const problems = [];
for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.js'))) {
  const src = fs.readFileSync(path.join(dir, f), 'utf8');
  const lits = src.match(/`[^`]*`/g) || [];
  for (const q of lits) {
    if (!/\b(SELECT|UPDATE|INSERT|DELETE)\b/.test(q)) continue;
    checked++;
    const re = /\b(COUNT|SUM|MAX|MIN|AVG)\s*\(/gi; let m;
    while ((m = re.exec(q))) {
      let depth = 0, j = m.index + m[0].length - 1;
      for (; j < q.length; j++) { if (q[j] === '(') depth++; else if (q[j] === ')' && --depth === 0) break; }
      const inner = q.slice(m.index + m[0].length, j);
      if (/\bSELECT\b/i.test(inner)) problems.push(`${f}: ${m[1]}(… SELECT …) → erro SQL 130: ${inner.slice(0, 90).replace(/\s+/g, ' ')}`);
    }
  }
}
if (problems.length) { console.error(problems.join('\n')); process.exit(1); }
console.log(`${checked} consultas verificadas: nenhuma agregação com subconsulta (erro 130)`);
