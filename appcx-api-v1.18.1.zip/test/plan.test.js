'use strict';
const assert = require('assert');
const path = require('path');
const plan = require('../src/lib/planConfig');
let n = 0; const t = (name, fn) => { fn(); n++; };

const D = plan.DEFAULTS;
t('turnos por defeito validos', () => { const v = plan.validateSection('templates', D.templates, D.templates); assert.strictEqual(v.items.length, 8); });
t('turno 8h sem almoco e recusado', () => assert.throws(() => plan.validateSection('templates', { lunchSlots: [13], items: [{ id: 'X1', start: '08:00', end: '16:00', hours: 8, lunch: false }] }, { items: [] }), /precisa de almoço/));
t('horas efetivas inconsistentes', () => assert.throws(() => plan.validateSection('templates', { lunchSlots: [13], items: [{ id: 'X1', start: '08:00', end: '17:00', hours: 9, lunch: true }] }, { items: [] }), /horas efetivas/));
t('turno retirado fica desativado', () => { const v = plan.validateSection('templates', { lunchSlots: [13], items: [D.templates.items[0]] }, D.templates); assert.strictEqual(v.items.length, 8); assert.strictEqual(v.items.filter((x) => x.active).length, 1); });
t('limite semanal AD >= diario', () => assert.throws(() => plan.validateSection('limits', { ...D.limits, adMaxWeekH: 1 }, D.limits), /semanal/));
t('data de arranque tem de ser segunda', () => { assert.throws(() => plan.validateSection('integration', { startDate: '2026-10-14' }, D.integration), /segunda/); assert.ok(plan.validateSection('integration', { forecastQueue: 'SAC', startDate: '2026-10-19', forecastUrl: 'https://x.azurewebsites.net' }, D.integration)); });
t('url https', () => assert.throws(() => plan.validateSection('integration', { forecastUrl: 'http://x' }, D.integration), /https/));
t('desvio fora do intervalo', () => assert.throws(() => plan.validateSection('deviation', { thresholdPct: 0 }, D.deviation), /Limiar/));
t('presenca P/R', () => { assert.strictEqual(plan.presenceOf('Almoço: 13h-14h P'), 'P'); assert.strictEqual(plan.presenceOf('Almoço: 15h-16h R'), 'R'); assert.strictEqual(plan.presenceOf('Almoço: 13h-14h'), ''); assert.strictEqual(plan.presenceOf('P e R'), ''); });

/* sugestao com o historico real */
const j = require(path.resolve('/mnt/user-data/uploads/TeamShift_SAC.json'));
const rows = j.shifts.map((s) => s.effective).filter((s) => ['', 'WORK'].includes(s.label) && s.group !== 'Supervisão').map((s) => ({ member: s.member, date: s.startDate, ad: s.ad }));
const ref = rows.reduce((m, r) => (r.date > m ? r.date : m), '');
const sug = plan.computeSuggestions(rows, ref);
const vals = Object.values(sug);
t('sugestao: todos com pelo menos 1 P e padrao valido', () => vals.forEach((v) => { assert.ok(/^[TF]{7}$/.test(v.workDays)); assert.ok(/^[PR-]{7}$/.test(v.presenceDays)); assert.ok(v.presenceDays.includes('P') || !v.enough); }));
const enough = vals.filter((v) => v.enough);
const monfri = enough.filter((v) => v.workDays === 'TTTTTFF').length;
console.log(`Sugestao: ${vals.length} operadores com historico recente; ${enough.length} com >= 4 semanas; ${monfri} seg-sex; ${vals.length - enough.length} sem historico suficiente; referencia ${ref}`);
const withP = enough.filter((v) => v.presenceDays.includes('P')).length;
console.log(`Com pelo menos 1 dia P sugerido: ${withP} de ${enough.length}`);
t('sugestao: maioria seg-sex', () => assert.ok(monfri / enough.length > 0.85));
console.log(n + ' testes do ciclo passaram');