'use strict';
/* Correções da matriz de testes v1.16.4 (API 1.17.6) */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const S = require('../src/lib/planSchedule');
let n = 0; const t = (name, f) => { f(); n++; };
const W = '2026-10-19'; /* segunda */

/* HO05: turno tardio na semana anterior */
t('turno tardio na semana anterior conta em lateLastWeek', () => {
  const rows = [
    { member: 'A', date: '2026-10-13', code: 'WORK', mins: 540, start: '11:00' },
    { member: 'A', date: '2026-10-14', code: 'WORK', mins: 540, start: '11:00' },
    { member: 'A', date: '2026-09-29', code: 'WORK', mins: 540, start: '08:00' },
    { member: 'B', date: '2026-10-13', code: 'WORK', mins: 540, start: '08:00' },
    { member: 'B', date: '2026-09-29', code: 'WORK', mins: 540, start: '11:00' }
  ];
  const b = S.computeBalances(rows, W, 4);
  assert.strictEqual(b.A.lateLastWeek, 2);
  assert.strictEqual(b.B.lateLastWeek, 0, 'tardio há 3 semanas não conta como semana anterior');
});

/* RG10: buraco no Forecast dentro do dia = horas sem necessidades */
const needs = [];
['08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30']
  .forEach((x) => needs.push({ day: W, t: x, len: 30, a: 3 }));
['18:00', '18:30', '19:00', '19:30'].forEach((x) => needs.push({ day: W, t: x, len: 30, a: 2 }));
t('turno que passa por intervalos sem linha no Forecast: aviso com as horas', () => {
  const r = S.zeroNeedCheck([{ member: 'A', date: W, start: '11:00', end: '20:00', code: 'WORK' }], needs);
  assert.strictEqual(r.errors.length, 0);
  assert.strictEqual(r.warnings.length, 1);
  assert.ok(/17:00–17:30/.test(r.warnings[0]) && /17:30–18:00/.test(r.warnings[0]), r.warnings[0]);
});
t('AD num buraco do Forecast: recusada', () => {
  const r = S.zeroNeedCheck([{ member: 'A', date: W, start: '17:00', end: '18:00', code: 'AD' }], needs);
  assert.strictEqual(r.errors.length, 1);
});
t('turno dentro das necessidades: sem avisos', () => {
  const r = S.zeroNeedCheck([{ member: 'A', date: W, start: '08:00', end: '16:00', code: 'WORK' }], needs);
  assert.strictEqual(r.errors.length + r.warnings.length, 0);
});

/* VI07 e OP03: verificações no código das consultas */
const src = (f) => fs.readFileSync(path.resolve(__dirname, '../src/lib', f), 'utf8');
t('aviso de semana publicada exclui quem publicou', () => {
  assert.ok(/PublishedBy, N''\) <> @e/.test(src('planClose.js')));
});
t('turno preferido não retira a confirmação do padrão', () => {
  assert.ok(/const changed = wd !== o\.workDays \|\| pd !== o\.presenceDays;/.test(src('planConfig.js')));
});
/* IN02: registo retirado por outra pessoa = conflito */
t('apagar um registo que já não existe (com versão) dá conflito', () => {
  assert.ok(/if \(!c\) \{ if \(d\.rowVer\) conflicts\.push\(d\.id\); continue; \}/.test(src('planSchedule.js')));
});

console.log(n + ' testes da versão 1.17.6 passaram');
