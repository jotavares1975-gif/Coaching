'use strict';
/* Justificações: retirar uma, limpar todas e estado da semana (base de dados simulada em memória). */
const assert = require('assert');
const path = require('path');
const dbPath = path.resolve(__dirname, '../src/lib/db.js');
const real = require(dbPath);
let J = [], state = 'EM_AJUSTE', audits = [];
function fakeRequest() {
  const inp = {};
  const r = { input(k, t, v) { inp[k] = v; if (k === 'w') r._w = v; if (k === 'id') r._id = Number(v); return r; }, async query(q) {
    if (/FROM dbo\.PlanWeeks/.test(q)) return { recordset: [{ State: state, WeekStart: new Date('2026-10-19T00:00:00Z'), Version: 1, ForecastId: 'F1', RowVer: Buffer.from([0]) }] };
    if (/DELETE FROM dbo\.Justifications/.test(q)) { const ids = JSON.parse(inp.ids).map(Number); J = J.filter((x) => !(x.week === inp.w && ids.includes(x.id))); return { recordset: [] }; }
    if (/INSERT INTO dbo\.AuditLog/.test(q)) { audits.push({ action: inp.Action, detail: inp.Detail, counts: inp.Counts }); return { recordset: [] }; }
    return { recordset: [] };
  } };
  return r;
}
const fakeQueryJson = async (r, q) => {
  if (/FROM dbo\.Justifications j JOIN dbo\.Reasons/.test(q)) {
    return J.filter((x) => x.week === r._w && (r._id == null || x.id === r._id)).map((x) => ({ id: x.id, day: x.day, hourFrom: x.hourFrom, hourTo: x.hourTo, reason: 'Absentismo' }));
  }
  return [];
};
require.cache[dbPath].exports = { ...real, request: fakeRequest, queryJson: fakeQueryJson, getPool: async () => ({}), isTransient: () => false };
const sched = require('../src/lib/planSchedule');
const adm = { isAdmin: true, role: 'PROJECT_ADMIN', teamScope: 'ALL' }, user = { email: 'a@medicare.pt', name: 'A' };
(async () => {
  let n = 0; const t = async (name, f) => { await f(); n++; };
  const seed = () => { J = [{ id: 1, week: '2026-S43', day: '2026-10-19', hourFrom: null, hourTo: null }, { id: 2, week: '2026-S43', day: '2026-10-20', hourFrom: 12, hourTo: 13 }, { id: 3, week: '2026-S44', day: '2026-10-26', hourFrom: null, hourTo: null }]; audits = []; state = 'EM_AJUSTE'; };
  await t('retirar uma justificação', async () => { seed(); const r = await sched.justify({}, user, adm, 'P', '2026-S43', { action: 'delete', id: 2 }); assert.strictEqual(r.cleared, 1); assert.deepStrictEqual(J.map((x) => x.id), [1, 3]); assert.strictEqual(audits[0].action, 'JUSTIFICATION_DELETE'); });
  await t('não retira justificações de outra semana', async () => { seed(); await assert.rejects(() => sched.justify({}, user, adm, 'P', '2026-S43', { action: 'delete', id: 3 }), /já não existe/); assert.strictEqual(J.length, 3); });
  await t('limpar todas só apaga a semana indicada', async () => { seed(); const r = await sched.justify({}, user, adm, 'P', '2026-S43', { action: 'clear' }); assert.strictEqual(r.cleared, 2); assert.deepStrictEqual(J.map((x) => x.id), [3]); assert.strictEqual(audits[0].action, 'JUSTIFICATION_CLEAR'); });
  await t('limpar sem justificações não falha nem audita', async () => { seed(); J = []; const r = await sched.justify({}, user, adm, 'P', '2026-S43', { action: 'clear' }); assert.strictEqual(r.cleared, 0); assert.strictEqual(audits.length, 0); });
  await t('semana fechada: não se retira nada', async () => { seed(); state = 'FECHADA'; await assert.rejects(() => sched.justify({}, user, adm, 'P', '2026-S43', { action: 'clear' }), /fechada/i); assert.strictEqual(J.length, 3); });
  await t('operador não retira', async () => { seed(); await assert.rejects(() => sched.justify({}, user, { isAdmin: false, role: 'UTILIZADOR' }, 'P', '2026-S43', { action: 'clear' }), /permissão/i); assert.strictEqual(J.length, 3); });
  console.log(n + ' testes das justificações passaram');
})().catch((e) => { console.error(e); process.exit(1); });
