'use strict';
/* Projeto de arranque ao iniciar sessão: o projeto de testes nunca é escolhido nem conta para pedir escolha. */
const assert = require('assert');
const { pickDefaultProject } = require('../src/lib/users');
const PROD = { projectId: 'TEAMSHIFT_SAC', isTest: false }, TEST = { projectId: 'TEAMSHIFT_SAC_TESTE', isTest: true, testSource: 'TEAMSHIFT_SAC' }, DRC = { projectId: 'DRC', isTest: false };
let n = 0; const t = (name, f) => { f(); n++; };
t('um projeto de produção e o de testes: entra na produção (AC05)', () => assert.strictEqual(pickDefaultProject([PROD, TEST], null, false), 'TEAMSHIFT_SAC'));
t('último usado foi o de testes: entra na produção de onde foi copiado', () => assert.strictEqual(pickDefaultProject([PROD, TEST], 'TEAMSHIFT_SAC_TESTE', false), 'TEAMSHIFT_SAC'));
t('vários de produção: entra no último usado', () => assert.strictEqual(pickDefaultProject([PROD, DRC, TEST], 'DRC', false), 'DRC'));
t('vários de produção sem último usado: pede escolha (só produção)', () => assert.strictEqual(pickDefaultProject([PROD, DRC, TEST], null, false), null));
t('vários de produção e último usado foi o de testes: entra na produção correspondente', () => assert.strictEqual(pickDefaultProject([PROD, DRC, TEST], 'TEAMSHIFT_SAC_TESTE', false), 'TEAMSHIFT_SAC'));
t('Administrador Geral sem último usado: primeiro de produção', () => assert.strictEqual(pickDefaultProject([TEST, PROD, DRC], null, true), 'TEAMSHIFT_SAC'));
t('último usado já sem acesso: ignora', () => assert.strictEqual(pickDefaultProject([PROD, TEST], 'OUTRO', false), 'TEAMSHIFT_SAC'));
t('só projeto de testes: não entra automaticamente', () => assert.strictEqual(pickDefaultProject([TEST], null, false), null));
console.log(n + ' testes do projeto de arranque passaram');
