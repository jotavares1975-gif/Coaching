'use strict';
/* Proteção contra repetição (M3) e Server-Timing (M1), com a base de dados simulada em memória. */
const assert = require('assert');
const path = require('path');
const dbPath = path.resolve(__dirname, '../src/lib/db.js');
const real = require(dbPath);
const table = new Map(); let failNext = false;
function fakeRequest() {
  const inp = {};
  return { input(k, t, v) { inp[k] = v; return this; }, async query(q) {
    if (/INSERT INTO dbo\.RequestKeys/.test(q)) { if (table.has(inp.k)) { const e = new Error('dup'); e.number = 2627; throw e; } table.set(inp.k, { Status: 'EM_CURSO' }); return { recordset: [] }; }
    if (/SELECT Status, ResponseStatus, ResponseBody FROM dbo\.RequestKeys/.test(q)) return { recordset: [table.get(inp.k)] };
    if (/UPDATE dbo\.RequestKeys SET Status = 'CONCLUIDO'/.test(q)) { table.set(inp.k, { Status: 'CONCLUIDO', ResponseStatus: inp.s, ResponseBody: inp.b }); return { recordset: [] }; }
    if (/DELETE FROM dbo\.RequestKeys WHERE KeyId/.test(q)) { table.delete(inp.k); return { recordset: [] }; }
    return { recordset: [] };
  } };
}
require.cache[dbPath].exports = { ...real, getPool: async () => ({}), request: fakeRequest, isTransient: () => false };
const { route, json, HttpError } = require('../src/lib/http');
let runs = 0;
const handler = route(async (req) => { runs++; if (failNext) { failNext = false; throw new HttpError(400, 'X', 'falhou'); } return json({ ok: true, n: runs }, 200, req); });
const mkReq = (key) => { const h = new Map(Object.entries({ 'x-idempotency-key': key })); return { method: 'POST', url: 'https://x/api/projects/P/plan/corrections', headers: { get: (k) => h.get(k) || null } }; };
(async () => {
  const ctx = { error() {} };
  const r1 = await handler(mkReq('kAAAAAAAAA1'), ctx);
  const r2 = await handler(mkReq('kAAAAAAAAA1'), ctx);
  assert.strictEqual(runs, 1, 'a repetição não pode executar de novo');
  assert.strictEqual(r2.headers['X-Idempotent-Replay'], '1');
  assert.strictEqual(JSON.parse(r2.body).n, 1);
  assert.ok(/sql;dur=\d+/.test(r1.headers['Server-Timing']));
  /* erro: a chave é libertada e uma nova tentativa executa */
  failNext = true;
  const r3 = await handler(mkReq('kBBBBBBBBB2'), ctx); assert.strictEqual(r3.status, 400);
  const r4 = await handler(mkReq('kBBBBBBBBB2'), ctx); assert.strictEqual(r4.status, 200); assert.strictEqual(runs, 3);
  /* pedido em curso: segunda chamada com a mesma chave enquanto a primeira não terminou */
  table.set('kCCCCCCCCC3', { Status: 'EM_CURSO' });
  const r5 = await handler(mkReq('kCCCCCCCCC3'), ctx); assert.strictEqual(r5.status, 409);
  /* sem chave: executa sempre */
  await handler({ method: 'POST', url: 'https://x/api/p', headers: { get: () => null } }, ctx); assert.strictEqual(runs, 4);
  console.log('6 testes da proteção contra repetição passaram');
})().catch((e) => { console.error(e); process.exit(1); });
