'use strict';
const assert = require('assert');
process.env.ALLOWED_EMAIL_DOMAIN = 'medicare.pt';
const auth = require('../src/lib/auth');
const perm = require('../src/lib/permissions');
const ch = require('../src/lib/changes');
const users = require('../src/lib/users');

let n = 0; const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const hdr = (o) => ({ headers: { get: (k) => o[k.toLowerCase()] ?? null } });
const principal = (claims) => Buffer.from(JSON.stringify({ auth_typ: 'aad', claims })).toString('base64');

t('principal lido do cabecalho', () => {
  const p = auth.parsePrincipal(hdr({ 'x-ms-client-principal': principal([{ typ: 'preferred_username', val: 'Jorge.Tavares@medicare.pt' }, { typ: 'name', val: 'Jorge' }]) }));
  assert.equal(p.email, 'jorge.tavares@medicare.pt');
});
t('sem autenticacao da plataforma -> recusa', () => {
  delete process.env.WEBSITE_AUTH_ENABLED; delete process.env.AUTH_ENFORCED_BY_PLATFORM;
  assert.throws(() => auth.requireIdentity(hdr({ 'x-ms-client-principal': principal([{ typ: 'preferred_username', val: 'a@medicare.pt' }]) })), (e) => e.status === 503);
});
t('dominio externo -> recusa', () => {
  process.env.WEBSITE_AUTH_ENABLED = 'True';
  assert.throws(() => auth.requireIdentity(hdr({ 'x-ms-client-principal': principal([{ typ: 'preferred_username', val: 'x@gmail.com' }]) })), (e) => e.status === 403);
});

const P = 'TEAMSHIFT_SAC';
const acc = (role, extra = {}, mods = [], teams = []) => auth.buildAccess({ ProjectId: P, Role: role, IsActive: 1, ...extra },
  mods.map((m) => ({ ModuleCode: m, CanEdit: 1 })), teams.map((x) => ({ Team: x })));
const geral = { email: 'jorge.tavares@medicare.pt', isGlobalAdmin: true, projects: {} };
const padmin = { email: 'pa@medicare.pt', isGlobalAdmin: false, projects: { [P]: acc('PROJECT_ADMIN') } };
const sup = { email: 'carolina.varela@medicare.pt', isGlobalAdmin: false,
  projects: { [P]: acc('SUPERVISOR', { CanImport: 1, CanRevertCorrections: 1 }, ['OPERATIONS'], ['carolina.varela@medicare.pt']) } };
const util = { email: 'dir@medicare.pt', isGlobalAdmin: false, projects: { [P]: acc('UTILIZADOR', { CanImport: 1 }, ['QUALITY']) } };

t('Administrador Geral tem acesso total a qualquer projecto', () => {
  const a = auth.projectAccess(geral, 'OUTRO');
  assert.equal(a.role, 'ADMIN_GERAL'); assert.ok(a.canImport && a.canRevert && a.canManageUsers);
});
t('sem acesso ao projecto -> recusa', () => {
  assert.throws(() => auth.projectAccess(sup, 'DRC'), (e) => e.code === 'SEM_ACESSO_PROJECTO');
});
t('Administrador de Projecto: total no seu projecto', () => {
  const a = auth.projectAccess(padmin, P);
  assert.ok(a.isAdmin && a.canManageUsers); assert.equal(auth.effectiveTeams(a, ''), null);
});
t('Supervisor so ve a sua equipa', () => {
  const a = auth.projectAccess(sup, P);
  assert.deepEqual(auth.effectiveTeams(a, ''), ['carolina.varela@medicare.pt']);
  assert.throws(() => auth.effectiveTeams(a, 'outra@medicare.pt'), (e) => e.status === 403);
});
t('Supervisor nao importa nem reverte, mesmo com autorizacao', () => {
  const a = auth.projectAccess(sup, P);
  assert.throws(() => perm.checkChangePermissions(a, { import: { importId: 'x' }, shifts: [{}] }), (e) => e.code === 'VISTA_COMPLETA');
  assert.throws(() => perm.checkChangePermissions(a, { overrides: { upsert: { k: {} } } }), (e) => e.status === 403);
});
t('Supervisor edita turnos da sua equipa (modulo com edicao)', () => {
  assert.deepEqual(perm.checkChangePermissions(auth.projectAccess(sup, P), { shifts: [{}] }), ['shifts']);
});
t('Seccao sem modulo editavel -> recusa', () => {
  assert.throws(() => perm.checkChangePermissions(auth.projectAccess(sup, P), { rhOperators: { upsert: { a: {} } } }), (e) => /operadores/.test(e.message));
});
t('Utilizador com importacao: so com vista completa', () => {
  const a = auth.projectAccess(util, P);
  assert.ok(perm.checkChangePermissions(a, { import: { importId: 'x' }, shifts: [{}] }));
  assert.throws(() => perm.checkChangePermissions(a, { import: { importId: 'x' }, viewTeam: 'eq', shifts: [{}] }), (e) => e.code === 'VISTA_COMPLETA');
});
t('Administrador com filtro de equipa nao reverte', () => {
  const a = auth.projectAccess(geral, P);
  assert.throws(() => perm.checkChangePermissions(a, { viewTeam: 'eq', overrides: { upsert: { k: {} } } }), (e) => e.code === 'VISTA_COMPLETA');
  assert.ok(perm.checkChangePermissions(a, { overrides: { upsert: { k: {} } } }));
});
t('Seccoes vazias nao contam', () => {
  assert.deepEqual(perm.presentSections({ rhOperators: { upsert: {}, remove: [] }, shifts: [] }), []);
});
t('Turno: ordem e colunas', () => {
  const f = ch.flatShift({ id: 'P|a|2026-01-02|#1', sortOrder: 15, effective: { member: 'A', startDate: '2026-01-02', startTime: '11:00' } });
  assert.equal(f.SortOrder, 15); assert.equal(f.E_StartTime, '11:00');
  assert.equal(ch.flatShift({ id: 'x', effective: {} }).SortOrder, null);
});
t('Gestao de utilizadores: quem administra o que', () => {
  assert.equal(users.administeredProjects(geral), null);
  assert.deepEqual(users.administeredProjects(padmin), [P]);
  assert.throws(() => users.requireUserManager(sup), (e) => e.status === 403);
  assert.throws(() => users.requireProjectAdmin(padmin, 'DRC'), (e) => e.status === 403);
  assert.throws(() => users.checkEmail('x@gmail.com'), (e) => e.code === 'EMAIL_INVALIDO');
});
console.log(`\n${n} testes passaram`);