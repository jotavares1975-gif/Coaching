'use strict';
const assert = require('assert');
const S = require('../src/lib/planSchedule');
let n = 0; const t = (name, f) => { f(); n++; };
const L = { adMaxDayH: 2, adMaxWeekH: 4, adBlockMin: 60, maxWorkDayH: 10, minRestH: 11, maxWorkDaysWeek: 5 };
const W = '2026-10-19'; /* segunda */
const row = (date, start, end, code = 'WORK', extra = {}) => ({ member: 'A', date, start, end, code, breakMin: code === 'WORK' ? 60 : 0, ...extra });
/* D1: descanso entre semanas */
t('domingo anterior até 22h e segunda às 08h: 10 h de descanso -> erro na segunda', () => {
  const e = S.validateWeek([row(W, '08:00', '17:00')], [row('2026-10-18', '13:00', '22:00')], ['A'], L, {}, W);
  assert.ok(e.some((x) => /2026-10-19/.test(x) && /descanso/.test(x)), e.join(' | '));
});
t('domingo da semana até 22h e segunda seguinte às 08h -> erro de descanso', () => {
  const e = S.validateWeek([row('2026-10-25', '13:00', '22:00')], [row('2026-10-26', '08:00', '17:00')], ['A'], L, {}, W);
  assert.ok(e.some((x) => /2026-10-26/.test(x) && /descanso/.test(x)), e.join(' | '));
});
t('sábado até 22h e domingo às 08h na mesma semana -> erro (fim de semana)', () => {
  const e = S.validateWeek([row('2026-10-24', '13:00', '22:00'), row('2026-10-25', '08:00', '15:00')], [], ['A'], L, {}, W);
  assert.ok(e.some((x) => /2026-10-25/.test(x) && /descanso/.test(x)), e.join(' | '));
});
t('dia vizinho com mais de 10 h não bloqueia a semana gravada', () => {
  const e = S.validateWeek([row(W, '09:00', '18:00')], [row('2026-10-26', '07:00', '20:00')], ['A'], L, {}, W);
  assert.strictEqual(e.length, 0, e.join(' | '));
});
t('12 h de descanso (20h -> 08h) passa', () => {
  const e = S.validateWeek([row(W, '08:00', '17:00')], [row('2026-10-18', '11:00', '20:00')], ['A'], L, {}, W);
  assert.strictEqual(e.length, 0, e.join(' | '));
});
/* M4: impressão digital da proposta */
const ops = [{ member: 'A', team: 't', workDays: 'TTTTTFF', presenceDays: 'PRRRR--', dailyHours: 8, status: 'CONFIRMADO', isActive: 1 }];
const settings = { templates: { items: [] }, limits: L };
t('impressão digital estável para os mesmos dados', () => {
  const rows = [{ id: 'x', rowVer: '0x1', src: 'EXCECAO' }, { id: 'y', rowVer: '0x2', src: 'PROPOSTA' }];
  assert.strictEqual(S.proposalBasis('F1', rows, ops, settings), S.proposalBasis('F1', rows.slice().reverse(), ops, settings));
});
t('muda se uma ausência muda', () => {
  const a = S.proposalBasis('F1', [{ id: 'x', rowVer: '0x1', src: 'EXCECAO' }], ops, settings);
  const b = S.proposalBasis('F1', [{ id: 'x', rowVer: '0x9', src: 'EXCECAO' }], ops, settings);
  assert.notStrictEqual(a, b);
});
t('muda se o padrão de um operador muda', () => {
  const a = S.proposalBasis('F1', [], ops, settings);
  const b = S.proposalBasis('F1', [], [{ ...ops[0], workDays: 'TTTTFFF' }], settings);
  assert.notStrictEqual(a, b);
});
t('não muda com ajustes manuais de horários (só dependências)', () => {
  const a = S.proposalBasis('F1', [{ id: 'y', rowVer: '0x2', src: 'MANUAL' }], ops, settings);
  const b = S.proposalBasis('F1', [{ id: 'y', rowVer: '0x7', src: 'MANUAL' }], ops, settings);
  assert.strictEqual(a, b);
});
t('muda se o ForecastId muda (reintegração)', () => {
  assert.notStrictEqual(S.proposalBasis('F1', [], ops, settings), S.proposalBasis('F2', [], ops, settings));
});
console.log(n + ' testes da fase 1 passaram');
/* fase 2 · D2 necessidades zero */
(() => {
  let k = 0; const tt = (name, f) => { f(); k++; };
  const needs = [{ day: '2026-10-24', t: '09:00', len: 30, a: 0 }, { day: '2026-10-24', t: '09:30', len: 30, a: 0 },
    { day: '2026-10-19', t: '08:00', len: 30, a: 2 }, { day: '2026-10-19', t: '08:30', len: 30, a: 3 }, { day: '2026-10-19', t: '19:00', len: 30, a: 1 }, { day: '2026-10-19', t: '19:30', len: 30, a: 0 }];
  tt('dia inteiro sem necessidades: bloqueia trabalho', () => { const r = S.zeroNeedCheck([{ member: 'A', date: '2026-10-24', start: '09:00', end: '15:00', code: 'WORK' }], needs); assert.strictEqual(r.errors.length, 1); });
  tt('AD numa hora com zero: bloqueia', () => { const r = S.zeroNeedCheck([{ member: 'A', date: '2026-10-19', start: '19:00', end: '20:00', code: 'AD' }], needs); assert.strictEqual(r.errors.length, 1); });
  tt('turno que toca numa hora com zero: só aviso', () => { const r = S.zeroNeedCheck([{ member: 'A', date: '2026-10-19', start: '11:00', end: '20:00', code: 'WORK' }], needs); assert.strictEqual(r.errors.length, 0); assert.strictEqual(r.warnings.length, 1); });
  tt('ausências não são afetadas', () => { const r = S.zeroNeedCheck([{ member: 'A', date: '2026-10-24', start: '09:00', end: '15:00', code: 'FE' }], needs); assert.strictEqual(r.errors.length + r.warnings.length, 0); });
  console.log(k + ' testes da regra de necessidades zero passaram');
})();
